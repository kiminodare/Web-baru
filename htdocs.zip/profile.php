<?php
session_start();
include 'test.php';
$id = $_SESSION['id'];
$query = "SELECT * FROM user WHERE id='$id'";
$result =@mysqli_query($koneksi,$query);
$row = mysqli_fetch_assoc($result);
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="main">
  <div class="image"><img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/ce4d3ce1-8ddc-41d8-8499-f8781586dfd1/ddbf68h-c731d440-b5ea-4a16-84f2-5e578497e52e.jpg/v1/fill/w_600,h_600,q_75,strp/p_o_r_t_a_l_by_ithar14_ddbf68h-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NjAwIiwicGF0aCI6IlwvZlwvY2U0ZDNjZTEtOGRkYy00MWQ4LTg0OTktZjg3ODE1ODZkZmQxXC9kZGJmNjhoLWM3MzFkNDQwLWI1ZWEtNGExNi04NGYyLTVlNTc4NDk3ZTUyZS5qcGciLCJ3aWR0aCI6Ijw9NjAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.G9DmLDmwTgJZM-JJlxmFbol2okInZQP_TX4hWi9Wywc"></div>
  <div class="stat">
   
  </div>
<div class=card>
  <h1><?php echo $_SESSION['username']; ?> </h1>
  <p>TOTAL CRE : <?php echo  $row['credit']; ?> </p>
  <div class="location">
  </div>
</div>