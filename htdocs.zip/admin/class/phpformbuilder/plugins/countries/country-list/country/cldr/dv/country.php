<?php return array (
  'MV' => 'ދިވެހި ރާއްޖެ',
);
