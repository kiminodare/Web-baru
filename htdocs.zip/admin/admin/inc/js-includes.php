<script src="<?php echo ADMIN_URL; ?>assets/javascripts/loadjs.min.js"></script>
<script>
    const adminUrl = '<?php echo ADMIN_URL; ?>';
    const classUrl = '<?php echo CLASS_URL; ?>';
    const datetimepickersStyle = '<?php echo DATETIMEPICKERS_STYLE; ?>';
</script>
<script src="<?php echo ADMIN_URL; ?>assets/javascripts/project.min.js"></script>
